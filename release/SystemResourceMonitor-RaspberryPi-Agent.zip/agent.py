#!/usr/bin/env python3
"""System Resource Monitor RFCOMM agent for Raspberry Pi OS / Linux."""
import json
import hmac
import platform
import secrets
import socket
import struct
import time

import psutil

SERVICE_UUID = "e05a0001-7f2b-4c4e-b7a3-1a7f6b1c9d10"
SERVICE_NAME = "System Resource Monitor"
MAX_FRAME_SIZE = 64 * 1024


def receive_frame(sock):
    size = struct.unpack("!I", receive_exact(sock, 4))[0]
    if size <= 0 or size > MAX_FRAME_SIZE:
        raise ValueError("Invalid request frame")
    return json.loads(receive_exact(sock, size).decode("utf-8"))


def receive_exact(sock, size):
    data = bytearray()
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            raise ConnectionError("Client disconnected")
        data.extend(chunk)
    return bytes(data)


def send_frame(sock, payload):
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    if len(body) > MAX_FRAME_SIZE:
        raise ValueError("Response frame is too large")
    sock.sendall(struct.pack("!I", len(body)) + body)


def process_snapshot(cpu_count):
    processes = []
    for process in psutil.process_iter(["pid", "name", "memory_percent"]):
        try:
            processes.append({
                "pid": process.pid,
                "name": process.info.get("name") or "Unknown",
                "cpu_percent_normalized": process.cpu_percent(interval=None) / cpu_count,
                "memory_percent": process.info.get("memory_percent") or 0.0,
            })
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            continue
    processes.sort(key=lambda item: item["cpu_percent_normalized"], reverse=True)
    return processes[:20]


def sample(cpu_count):
    return {
        "type": "sample",
        "timestamp": time.time(),
        "cpu": psutil.cpu_percent(interval=0.5),
        "memory": psutil.virtual_memory().percent,
        "gpu": None,
        "gpu_memory": None,
        "processes": process_snapshot(cpu_count),
    }


def serve_client(client, cpu_count):
    hello = receive_frame(client)
    if hello.get("type") != "hello" or hello.get("protocol") != 2:
        raise ValueError("Unsupported monitor protocol")
    code = f"{secrets.randbelow(90000) + 10000:05d}"
    print(f"Bluetooth connection verification code: {code}", flush=True)
    send_frame(client, {"type": "auth_required", "protocol": 2})
    client.settimeout(90)
    auth = receive_frame(client)
    accepted = (auth.get("type") == "auth" and
                hmac.compare_digest(str(auth.get("code", "")), code))
    send_frame(client, {"type": "authorized" if accepted else "auth_failed"})
    if not accepted:
        raise PermissionError("Bluetooth connection verification failed")
    client.settimeout(None)
    send_frame(client, {"type": "hello", "protocol": 2, "name": platform.node()})
    while True:
        request = receive_frame(client)
        if request.get("type") != "sample":
            return
        send_frame(client, sample(cpu_count))


def main():
    try:
        import bluetooth
    except ImportError as exc:
        raise SystemExit(
            "Bluetooth module missing. Install it with: sudo apt install python3-bluez"
        ) from exc

    server = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
    server.bind(("", bluetooth.PORT_ANY))
    server.listen(1)
    channel = server.getsockname()[1]
    bluetooth.advertise_service(
        server,
        SERVICE_NAME,
        service_id=SERVICE_UUID,
        service_classes=[SERVICE_UUID, bluetooth.SERIAL_PORT_CLASS],
        profiles=[bluetooth.SERIAL_PORT_PROFILE],
    )

    cpu_count = max(1, psutil.cpu_count(logical=True) or 1)
    print(f"Advertising {SERVICE_NAME} on RFCOMM channel {channel} ({SERVICE_UUID})")
    print("Leave this process running. Press Ctrl+C to stop.")
    try:
        while True:
            client, address = server.accept()
            print("Connected:", address[0])
            try:
                serve_client(client, cpu_count)
            except (OSError, ValueError, ConnectionError) as exc:
                print("Client ended:", exc)
            finally:
                client.close()
    except KeyboardInterrupt:
        print("Stopping Bluetooth monitor agent")
    finally:
        server.close()


if __name__ == "__main__":
    main()
