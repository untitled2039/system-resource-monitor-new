# Raspberry Pi Bluetooth agent

The agent speaks the same Bluetooth Classic RFCOMM protocol as the Windows app and advertises the app's service UUID. Raspberry Pi OS with a Bluetooth Classic adapter is required.

From the project folder on the Pi:

```bash
cd agents/raspberry_pi
sudo sh ./install.sh
```

The installer adds BlueZ, `python3-bluez`, and `psutil`, installs a systemd service, and starts the agent. Check it with `sudo journalctl -u system-resource-monitor-agent -f`. In the Windows app, search again and select the Raspberry Pi entry marked **Monitor agent available**.

When Windows connects, the Pi prints a randomly generated 5-digit verification code to the service log. Keep this command open while connecting:

```bash
sudo journalctl -u system-resource-monitor-agent -f
```

Enter the displayed code in the Windows verification dialog within 90 seconds. Update the Pi agent before using this handshake; older agent versions do not support it.

The agent returns CPU, memory, and the top 20 Linux processes. GPU fields are currently empty. The service account is selected from `sudo`; if your Pi uses a different login, the installer uses that account.
