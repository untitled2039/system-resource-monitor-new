#!/bin/sh
set -eu

AGENT_DIR="/opt/system-resource-monitor-agent"
SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
SERVICE_USER=${SUDO_USER:-pi}

if [ "$(id -u)" -ne 0 ]; then
    echo "Run with sudo: sudo ./install.sh"
    exit 1
fi

apt-get update
apt-get install -y bluez python3-bluez python3-psutil
install -d -o "$SERVICE_USER" -g "$SERVICE_USER" "$AGENT_DIR"
install -m 0755 "$SCRIPT_DIR/agent.py" "$AGENT_DIR/agent.py"
sed "s/^User=pi$/User=$SERVICE_USER/" \
    "$SCRIPT_DIR/system-resource-monitor-agent.service" \
    > /etc/systemd/system/system-resource-monitor-agent.service
systemctl daemon-reload
systemctl enable --now system-resource-monitor-agent.service
systemctl --no-pager --full status system-resource-monitor-agent.service
